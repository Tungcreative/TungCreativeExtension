const REMOTE_EVENT_LOGO_URL = "https://tungcreativextension.tungcreativevn.workers.dev/logo_event.png"; 

document.addEventListener('DOMContentLoaded', () => {
  const searchForm = document.getElementById('searchForm');
  const searchInput = document.getElementById('searchInput');
  const searchBoxWrapper = document.getElementById('searchBoxWrapper');
  const mainLogo = document.getElementById('mainLogo');
  const suggestionsList = document.getElementById('suggestionsList');
  const dailyQuote = document.getElementById('dailyQuote');

  function updateLogo(useEvent) {
    if (mainLogo) {
      mainLogo.src = useEvent ? REMOTE_EVENT_LOGO_URL : chrome.runtime.getURL('logo.png');
    }
  }
  chrome.storage.local.get(['useEventLogo'], (res) => {
    updateLogo(!!res.useEventLogo);
  });
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.useEventLogo) {
      updateLogo(changes.useEventLogo.newValue);
    }
  });

  function getGreeting() {
    const currentHour = new Date().getHours();
    if (currentHour >= 3 && currentHour < 12) return 'Chào buổi sáng!';
    if (currentHour >= 12 && currentHour < 18) return 'Chào buổi chiều!';
    if (currentHour >= 18 && currentHour < 22) return 'Chào buổi tối!';
    return 'Developed by TungCreative';
  }
  const phrases = [
    getGreeting(),
    'Tìm trên Google hoặc nhập một URL'
  ];

  let phraseIndex = 0;
  let charIndex = 0;
  let isDeleting = false;
  let typingSpeed = 70;

  function typePlaceholder() {
    if (searchInput.value.length > 0) {
      setTimeout(typePlaceholder, 1000);
      return;
    }
    const currentPhrase = phrases[phraseIndex];

    if (isDeleting) {
      searchInput.setAttribute('placeholder', currentPhrase.substring(0, charIndex - 1));
      charIndex--;
      typingSpeed = 35;
    } else {
      searchInput.setAttribute('placeholder', currentPhrase.substring(0, charIndex + 1));
      charIndex++;
      typingSpeed = 70;
    }

    if (!isDeleting && charIndex === currentPhrase.length) {
      typingSpeed = 2500;
      isDeleting = true;
    } else if (isDeleting && charIndex === 0) {
      isDeleting = false;
      phraseIndex = (phraseIndex + 1) % phrases.length;
      typingSpeed = 400;
    }

    setTimeout(typePlaceholder, typingSpeed);
  }
  setTimeout(typePlaceholder, 2300);

  const quotes = [
    '"Chìa khóa để thành công là kiên trì, không phải tốc độ" - Tony Robbins',
    '"Cách duy nhất để vượt qua mọi thử thách là không bao giờ bỏ cuộc" - Zig Ziglar',
    '"Kiên trì không chỉ là khả năng chịu đựng, mà còn là khả năng bắt đầu lại" - Napoleon Hill',
    '"Khi bạn tiếp tục kiên trì, cả vũ trụ sẽ âm thầm hỗ trợ bạn" - Paulo Coelho',
    '"Người duy nhất có thể ngăn bạn đạt được mục tiêu là chính bạn" - Les Brown',
    '"Không có gì thay thế được sự kiên trì, kể cả tài năng hay trí tuệ" - Calvin Coolidge',
    '"Đổi mới bắt đầu từ việc đặt câu hỏi và tìm câu trả lời khác biệt" - Warren Berger',
    '"Sáng tạo là một hành trình, không phải một đích đến" - Twyla Tharp',
    '"Chúng ta không thể tạo ra cái mới nếu chúng ta vẫn giữ mãi cái cũ" - Henry Ford',
    '"TungCreative - Nơi chắp cánh cho những ý tưởng sáng tạo"'
  ];
  if (dailyQuote) {
    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    dailyQuote.textContent = randomQuote;
  }

  setTimeout(() => {
    if (searchInput) {
      searchInput.focus();
    }
  }, 300);

  let selectedSuggestionIndex = -1;
  let debounceTimeout = null;
  async function fetchSuggestions(query) {
    if (!query) {
      closeSuggestions();
      return;
    }
    try {
      const response = await fetch(`https://suggestqueries.google.com/complete/search?client=chrome&q=${encodeURIComponent(query)}`);
      const data = await response.json();
      const suggestions = data[1] || [];
      renderSuggestions(suggestions);
    } catch (e) {
      closeSuggestions();
    }
  }

  function renderSuggestions(items) {
    if (!items || items.length === 0) {
      closeSuggestions();
      return;
    }
    suggestionsList.innerHTML = '';
    selectedSuggestionIndex = -1;

    items.slice(0, 5).forEach((text) => {
      const li = document.createElement('li');
      li.className = 'suggestion-item';
      li.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="11" cy="11" r="8"></circle>
          <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
        </svg>
        <span>${text}</span>
      `;
      li.addEventListener('mousedown', (e) => {
        e.preventDefault();
        searchInput.value = text;
        executeQuery();
      });
      suggestionsList.appendChild(li);
    });

    suggestionsList.classList.add('active');
    searchBoxWrapper.classList.add('has-suggestions');
    if (dailyQuote) dailyQuote.classList.add('hidden-quote');
  }

  function closeSuggestions() {
    suggestionsList.innerHTML = '';
    suggestionsList.classList.remove('active');
    searchBoxWrapper.classList.remove('has-suggestions');
    if (dailyQuote) dailyQuote.classList.remove('hidden-quote');
    selectedSuggestionIndex = -1;
  }

  searchInput.addEventListener('input', (e) => {
    const val = e.target.value.trim();
    clearTimeout(debounceTimeout);
    debounceTimeout = setTimeout(() => {
      fetchSuggestions(val);
    }, 150);
  });

  searchInput.addEventListener('keydown', (e) => {
    const items = suggestionsList.querySelectorAll('.suggestion-item');
    if (!items.length) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      selectedSuggestionIndex = (selectedSuggestionIndex + 1) % items.length;
      updateSelectedSuggestion(items);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      selectedSuggestionIndex = (selectedSuggestionIndex - 1 + items.length) % items.length;
      updateSelectedSuggestion(items);
    } else if (e.key === 'Escape') {
      closeSuggestions();
    }
  });

  function updateSelectedSuggestion(items) {
    items.forEach((item, idx) => {
      if (idx === selectedSuggestionIndex) {
        item.classList.add('selected');
        searchInput.value = item.querySelector('span').textContent;
      } else {
        item.classList.remove('selected');
      }
    });
  }

  document.addEventListener('click', (e) => {
    if (!searchBoxWrapper.contains(e.target)) {
      closeSuggestions();
    }
  });

  function isURL(str) {
    if (/\s/.test(str)) return false;
    if (/^https?:\/\//i.test(str)) {
      try {
        new URL(str);
        return true;
      } catch (_) {
        return false;
      }
    }
    const domainPattern = /^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}(\/.*)?$/i;
    return domainPattern.test(str);
  }

  function executeQuery() {
    const query = searchInput.value.trim();
    if (!query) {
      return;
    }
    closeSuggestions();
    if (isURL(query)) {
      const destination = /^https?:\/\//i.test(query) ? query : 'https://' + query;
      window.location.href = destination;
    } else {
      window.location.href = 'https://www.google.com/search?q=' + encodeURIComponent(query);
    }
  }
  searchForm.addEventListener('submit', (e) => {
    e.preventDefault();
    e.stopPropagation();
    executeQuery();
  });
});