@echo off
chcp 65001 >nul
title Cai dat TungCreative cho 1 Tai khoan chi dinh
color 0a

echo ===================================================
echo      CHỌN HỒ SƠ GOOGLE CHROME BẠN MUỐN CÀI ĐẶT
echo ===================================================
echo.
echo [1] Tài khoản mặc định (Profile Default)
echo [2] Tài khoản phụ 1 (Profile 1)
echo [3] Tài khoản phụ 2 (Profile 2)
echo.
set /p choice="Nhập lựa chọn của bạn (1, 2 hoac 3): "

if "%choice%"=="1" set "PROF_DIR=Default"
if "%choice%"=="2" set "PROF_DIR=Profile 1"
if "%choice%"=="3" set "PROF_DIR=Profile 2"

set "TARGET_DIR=%LocalAppData%\Google\Chrome\User Data\%PROF_DIR%\Extensions\TungCreative"

echo.
echo [*] Đang cài đặt vào: %PROF_DIR%...
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
xcopy /s /e /y /q "%~dp0*" "%TARGET_DIR%\" >nul

if exist "%TARGET_DIR%\CaiDat_Profile.bat" del /f /q "%TARGET_DIR%\CaiDat_Profile.bat"

echo.
echo ===================================================
echo       CÀI ĐẶT HOÀN TẤT CHO TÀI KHOẢN ĐÃ CHỌN!
echo ===================================================
echo Thư mục lưu: %TARGET_DIR%
echo.

echo.
echo                                                   -- 𝑫𝒆𝒗𝒆𝒍𝒐𝒑𝒆𝒅 𝒃𝒚 𝑻𝒖𝒏𝒈𝑪𝒓𝒆𝒂𝒕𝒊𝒗𝒆 --
echo.
pause