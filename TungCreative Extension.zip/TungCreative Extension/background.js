if (chrome.storage && chrome.storage.session) {
  chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });
}

function isWhitelistedUrl(url) {
  if (!url) return false;
  if (url.startsWith('chrome://newtab') || url.startsWith('chrome-extension://')) return true;
  if (url.includes('tungcreativevn.workers.dev')) return true;
  return false;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'OPEN_NEW_TAB') {
    if (sender.tab && sender.tab.id) {
      chrome.tabs.update(sender.tab.id, { url: 'chrome://newtab' });
    }
  }
  if (message.action === 'CLOSE_TAB') {
    if (sender.tab && sender.tab.id) {
      chrome.tabs.remove(sender.tab.id);
    }
  }
});