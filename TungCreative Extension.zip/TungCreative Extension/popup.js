document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('eventLogoToggle');

  chrome.storage.local.get(['useEventLogo'], (res) => {
    toggle.checked = !!res.useEventLogo;
  });

  toggle.addEventListener('change', () => {
    chrome.storage.local.set({ useEventLogo: toggle.checked });
  });

  document.getElementById('openTabBtn').addEventListener('click', () => {
    chrome.tabs.create({ url: 'chrome://newtab' });
  });

  document.getElementById('openYtBtn').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://www.youtube.com/@TSTtungsangtao' });
  });
});