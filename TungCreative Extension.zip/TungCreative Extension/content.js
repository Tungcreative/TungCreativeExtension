let currentBase64 = null;
let currentLogoName = null;

const REMOTE_EVENT_LOGO_URL = "https://tungcreativextension.tungcreativevn.workers.dev/"; 

const VALID_LICENSE_KEYS = [
    "TUNGCREATIVE-2126-2110"
];
const MASTER_RESET_KEY = "TC-R-2110";
const DEFAULT_PIN = "211021";
const MAX_ATTEMPTS = 3;
let failedCount = 0;

function injectGlobalLockStyles() {
  if (document.getElementById('tc-global-lock-style')) return;
  const style = document.createElement('style');
  style.id = 'tc-global-lock-style';
  style.textContent = `
    html, body {
      overflow: hidden !important;
      height: 100vh !important;
      width: 100vw !important;
      margin: 0 !important;
      padding: 0 !important;
      user-select: none !important;
      -webkit-user-select: none !important;
    }
  `;
  (document.head || document.documentElement).appendChild(style);
}

function removeGlobalLockStyles() {
  const style = document.getElementById('tc-global-lock-style');
  if (style) style.remove();
}

function enableAntiDevTools() {
  window.addEventListener('contextmenu', (e) => e.preventDefault(), true);

  window.addEventListener('keydown', (e) => {
    if (e.key === 'F12' || e.keyCode === 123) {
      e.preventDefault();
      triggerLockdown('Phát hiện nhấn F12 trên Google');
      return false;
    }
    if (e.ctrlKey && e.shiftKey && ['I','i','J','j','C','c'].includes(e.key)) {
      e.preventDefault();
      triggerLockdown('Phát hiện mở DevTools trên Google');
      return false;
    }
    if (e.ctrlKey && (e.key === 'U' || e.key === 'u' || e.key === 'S' || e.key === 's')) {
      e.preventDefault();
      return false;
    }
  }, true);
}

async function triggerLockdown(reason) {
  await chrome.storage.local.set({ isLockedDown: true, lockdownReason: reason });
  const oldLock = document.getElementById('tungcreative-lock-screen') || document.getElementById('tungcreative-license-screen');
  if (oldLock) oldLock.remove();
  renderLockdownScreen(reason);
}

function loadFontAwesome() {
  if (!document.getElementById('fa-cdn-css')) {
    const link = document.createElement('link');
    link.id = 'fa-cdn-css';
    link.rel = 'stylesheet';
    link.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css';
    (document.head || document.documentElement).appendChild(link);
  }
}

function isWhitelistedOrigin() {
  const host = window.location.hostname;
  return host === 'tungcreativevn.workers.dev' || host.endsWith('.tungcreativevn.workers.dev');
}

function formatSmartKeyInput(inputElem) {
  inputElem.addEventListener('input', (e) => {
    if (e.inputType === 'deleteContentBackward' || e.inputType === 'deleteContentForward') return;
    let raw = inputElem.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    let matchedPattern = null;

    for (const key of VALID_LICENSE_KEYS) {
      const cleanKey = key.replace(/[^A-Z0-9]/g, '');
      if (cleanKey.startsWith(raw)) {
        matchedPattern = key;
        break;
      }
    }

    if (matchedPattern) {
      let formatted = '';
      let rawIdx = 0;
      for (let i = 0; i < matchedPattern.length && rawIdx < raw.length; i++) {
        if (matchedPattern[i] === '-') {
          formatted += '-';
        } else {
          formatted += raw[rawIdx];
          rawIdx++;
        }
      }
      if (formatted.length < matchedPattern.length && matchedPattern[formatted.length] === '-') {
        formatted += '-';
      }
      inputElem.value = formatted;
    } else {
      inputElem.value = inputElem.value.toUpperCase();
    }
  });
}

function renderLockdownScreen(reason) {
  loadFontAwesome();
  injectGlobalLockStyles();

  if (document.getElementById('tungcreative-panic-screen')) return;

  const overlay = document.createElement('div');
  overlay.id = 'tungcreative-panic-screen';
  overlay.style.cssText = `
    position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important;
    width: 100vw !important; height: 100vh !important; background: #000000 !important; z-index: 2147483647 !important;
    display: flex !important; flex-direction: column !important; align-items: center !important; justify-content: center !important;
    font-family: 'Segoe UI', Tahoma, sans-serif !important; color: #ff4d4f !important; pointer-events: all !important;
  `;
  overlay.innerHTML = `
    <div style="background: #160b0b; border: 2px solid #ff4d4f; padding: 40px 32px; border-radius: 16px; width: 380px; box-shadow: 0 0 50px rgba(255, 77, 79, 0.4); text-align: center;">
      <div style="font-size: 46px; margin-bottom: 12px; color: #ff4d4f;"><i class="fa-solid fa-triangle-exclamation"></i></div>
      <h2 style="margin: 0 0 8px 0; font-size: 22px; color: #ff4d4f; font-weight: 700; text-transform: uppercase;">TRUY CẬP BỊ TẠM KHÓA</h2>
      <p style="margin: 0 0 16px 0; font-size: 13px; color: #d1d5db;">Hệ thống phát hiện hành vi: <br><b style="color: #ff7875;">${reason || 'Chưa mở khóa xác thực'}</b></p>
      <p style="font-size: 12px; color: #8b949e; margin-bottom: 20px;">Vui lòng nhập Master Key của quản trị viên để mở lại màn hình làm việc.</p>
      
      <div id="tst-reset-box" style="margin-bottom: 15px;">
        <input type="password" id="tst-master-input" placeholder="Nhập Master Key..." autofocus style="width: 100%; padding: 12px 14px; background: #0d1117; border: 1.5px solid #ff4d4f; border-radius: 8px; color: #fff; text-align: center; outline: none; margin-bottom: 10px; font-size: 14px; box-sizing: border-box;" />
        <button id="tst-master-btn" style="width: 100%; padding: 11px; background: #30ab51; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 14px;">XÁC NHẬN MỞ KHÓA</button>
      </div>
    </div>
  `;
  document.documentElement.appendChild(overlay);

  const masterInput = overlay.querySelector('#tst-master-input');
  const masterBtn = overlay.querySelector('#tst-master-btn');

  const handleMasterUnlock = async () => {
    const inputKey = masterInput.value.trim().toUpperCase();
    if (inputKey === MASTER_RESET_KEY) {
      await chrome.storage.local.set({ isLockedDown: false });
      await chrome.storage.session.set({ isUnlocked: true });
      overlay.remove();
      removeGlobalLockStyles();
      location.reload();
    } else {
      masterInput.style.borderColor = '#ff4d4f';
      masterInput.value = '';
      alert('Master Key không chính xác!');
      masterInput.focus();
    }
  };

  masterBtn.addEventListener('click', handleMasterUnlock);
  masterInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleMasterUnlock();
    }
  });

  const antiTamper = new MutationObserver(() => {
    if (!document.getElementById('tungcreative-panic-screen')) {
      chrome.storage.local.get(['isLockedDown'], (res) => {
        if (res.isLockedDown) renderLockdownScreen(reason);
      });
    }
  });
  antiTamper.observe(document.documentElement, { childList: true });
}

async function checkSearchLock() {
  if (isWhitelistedOrigin()) return;

  enableAntiDevTools();
  loadFontAwesome();

  const localData = await chrome.storage.local.get(['isActivated', 'isLockedDown', 'lockdownReason', 'appPassword']);

  if (localData.isLockedDown) {
    renderLockdownScreen(localData.lockdownReason);
    return;
  }

  if (!localData.isActivated) {
    injectGlobalLockStyles();

    const overlay = document.createElement('div');
    overlay.id = 'tungcreative-license-screen';
    overlay.style.cssText = `
      position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important;
      width: 100vw !important; height: 100vh !important; background: #000000 !important; z-index: 2147483647 !important;
      display: flex !important; flex-direction: column !important; align-items: center !important; justify-content: center !important;
      font-family: 'Segoe UI', Tahoma, sans-serif !important; color: #ffffff !important; pointer-events: all !important;
    `;
    overlay.innerHTML = `
      <div style="background: #161b22; border: 1px solid #30363d; padding: 36px 32px; border-radius: 16px; width: 360px; box-shadow: 0 12px 30px rgba(0,0,0,0.6); text-align: center;">
        <div style="font-size: 38px; margin-bottom: 8px; color: #30ab51;"><i class="fa-solid fa-certificate"></i></div>
        <h2 style="margin: 0 0 8px 0; font-size: 20px; color: #30ab51; font-weight: 600;">Kích Hoạt Bản Quyền</h2>
        <p style="margin: 0 0 16px 0; font-size: 13px; color: #8b949e;">Vui lòng nhập License Key để sử dụng</p>
        <input type="text" id="tst-license-input" placeholder="TUNGCREATIVE-2126-2110" autofocus style="width: 100%; padding: 12px 14px; background: #0d1117; border: 1.5px solid #30363d; border-radius: 8px; color: #ffffff; font-size: 14px; outline: none; box-sizing: border-box; text-align: center; letter-spacing: 1.5px;" />
        <p id="tst-license-error" style="color: #ff4d4f; font-size: 12px; margin: 10px 0 0 0; min-height: 16px; visibility: hidden; font-weight: 500;">License Key không hợp lệ!</p>
        <button id="tst-license-btn" style="width: 100%; margin-top: 14px; padding: 11px; background: #30ab51; color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px;">
          <i class="fa-solid fa-check"></i> KÍCH HOẠT
        </button>
      </div>
    `;
    document.documentElement.appendChild(overlay);
    const input = overlay.querySelector('#tst-license-input');
    const btn = overlay.querySelector('#tst-license-btn');
    const err = overlay.querySelector('#tst-license-error');
    
    formatSmartKeyInput(input);
    input.focus();

    let isSelfRemoving = false;
    const handleActivate = async () => {
      const enteredKey = input.value.trim().toUpperCase();
      if (VALID_LICENSE_KEYS.includes(enteredKey)) {
        isSelfRemoving = true;
        await chrome.storage.local.set({ isActivated: true, activatedKey: enteredKey });
        overlay.remove();
        removeGlobalLockStyles();
        await chrome.storage.session.set({ isUnlocked: true });
      } else {
        err.style.visibility = 'visible';
        input.style.borderColor = '#ff4d4f';
        input.value = '';
        input.focus();
      }
    };
    btn.addEventListener('click', handleActivate);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') handleActivate();
      if (e.key === 'Escape') {
        e.preventDefault();
        triggerLockdown('Không nhập License Key');
      }
    });

    const antiTamper = new MutationObserver(() => {
      if (!isSelfRemoving && !document.getElementById('tungcreative-license-screen')) {
        chrome.storage.local.get(['isActivated'], (res) => {
          if (!res.isActivated) triggerLockdown('Cố tình gỡ màn hình bản quyền');
        });
      }
    });
    antiTamper.observe(document.documentElement, { childList: true });
    return;
  }

  const session = await chrome.storage.session.get(['isUnlocked']);
  if (session.isUnlocked) return;

  injectGlobalLockStyles();

  const correctPassword = localData.appPassword || DEFAULT_PIN;

  const overlay = document.createElement('div');
  overlay.id = 'tungcreative-lock-screen';
  overlay.style.cssText = `
    position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important;
    width: 100vw !important; height: 100vh !important; background: #000000 !important; z-index: 2147483647 !important;
    display: flex !important; flex-direction: column !important; align-items: center !important; justify-content: center !important;
    font-family: 'Segoe UI', Tahoma, sans-serif !important; color: #ffffff !important; pointer-events: all !important;
  `;
  overlay.innerHTML = `
    <div style="background: #161b22; border: 1px solid #30363d; padding: 36px 32px; border-radius: 16px; width: 340px; box-shadow: 0 12px 30px rgba(0,0,0,0.6); text-align: center;">
      <div style="font-size: 38px; margin-bottom: 8px; color: #ffffff;"><i class="fa-solid fa-lock"></i></div>
      <h2 style="margin: 0 0 8px 0; font-size: 20px; color: #30ab51; font-weight: 600;">TungCreative Extension</h2>
      <p style="margin: 0 0 16px 0; font-size: 13px; color: #8b949e;">Developed by TungCreative</p>
      <input type="password" id="tst-lock-input" placeholder="Nhập mật khẩu..." autofocus style="width: 100%; padding: 12px 14px; background: #0d1117; border: 1.5px solid #30363d; border-radius: 8px; color: #ffffff; font-size: 15px; outline: none; box-sizing: border-box; text-align: center; letter-spacing: 2px;" />
      <p id="tst-lock-error" style="color: #ff4d4f; font-size: 12px; margin: 10px 0 0 0; min-height: 16px; visibility: hidden; font-weight: 500;">Mật khẩu không chính xác!</p>
      <button id="tst-lock-btn" style="width: 100%; margin-top: 14px; padding: 11px; background: #30ab51; color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer;">MỞ KHÓA</button>
    </div>
  `;
  document.documentElement.appendChild(overlay);
  const input = overlay.querySelector('#tst-lock-input');
  const btn = overlay.querySelector('#tst-lock-btn');
  const err = overlay.querySelector('#tst-lock-error');
  input.focus();

  let isSelfRemoving = false;

  const handleUnlock = async () => {
    if (input.value === correctPassword) {
      isSelfRemoving = true;
      await chrome.storage.session.set({ isUnlocked: true });
      overlay.remove();
      removeGlobalLockStyles();
    } else {
      failedCount++;
      const remain = MAX_ATTEMPTS - failedCount;
      if (remain <= 0) {
        isSelfRemoving = true;
        overlay.remove();
        triggerLockdown('Nhập sai mật khẩu quá 3 lần');
      } else {
        err.textContent = `Sai mật khẩu! Còn ${remain} lần thử`;
        err.style.visibility = 'visible';
        input.style.borderColor = '#ff4d4f';
        input.value = '';
        input.focus();
      }
    }
  };

  btn.addEventListener('click', handleUnlock);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') handleUnlock();
    if (e.key === 'Escape') e.preventDefault();
  });

  const antiTamper = new MutationObserver(() => {
    if (!isSelfRemoving && !document.getElementById('tungcreative-lock-screen')) {
      chrome.storage.session.get(['isUnlocked'], (res) => {
        if (!res.isUnlocked) triggerLockdown('Cố tình gỡ màn hình khóa');
      });
    }
  });
  antiTamper.observe(document.documentElement, { childList: true });
}
checkSearchLock();

async function getLogoBase64(isEvent) {
  const targetKey = isEvent ? 'event' : 'default';
  if (currentLogoName === targetKey && currentBase64) return currentBase64;

  let fetchUrl = isEvent ? REMOTE_EVENT_LOGO_URL : chrome.runtime.getURL('logo.png');

  try {
    const response = await fetch(fetchUrl);
    const blob = await response.blob();
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        currentBase64 = reader.result;
        currentLogoName = targetKey;
        resolve(currentBase64);
      };
      reader.readAsDataURL(blob);
    });
  } catch (err) {
    const fallbackResponse = await fetch(chrome.runtime.getURL('logo.png'));
    const blob = await fallbackResponse.blob();
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        currentBase64 = reader.result;
        currentLogoName = targetKey;
        resolve(currentBase64);
      };
      reader.readAsDataURL(blob);
    });
  }
}

function injectThemeStyles() {
  if (document.getElementById('tungcreative-search-theme')) return;

  const style = document.createElement('style');
  style.id = 'tungcreative-search-theme';
  style.textContent = `
    a:link h3, a:link .LC20lb, .MjjYud a:link h3 { color: #30ab51 !important; transition: color 0.15s ease !important; }
    a:visited h3, a:visited .LC20lb, .MjjYud a:visited h3 { color: #1f6f35 !important; }
    a:hover h3, .LC20lb:hover { color: #248b3f !important; text-decoration: underline !important; }
    .VwiC3b, .hgKElc, .kno-rdesc, .kno-rdesc span, .BNeawe, .s3v9rd, em { color: #4d5156 !important; }
    cite, .VuuXrf { color: #202124 !important; }
    .RNNXgb:focus-within, .emca:focus-within { box-shadow: 0 1px 6px rgba(48, 171, 81, 0.35), 0 0 0 2px #30ab51 !important; border-color: #30ab51 !important; }
    .mJ2Mod .NZmxef, .YmvwI.mJ2Mod, [role="tab"][aria-selected="true"] { border-bottom-color: #30ab51 !important; color: #30ab51 !important; }
    .goxjub, .Tg7LZd svg, #foot .YyVfkd { color: #30ab51 !important; }
  `;
  (document.head || document.documentElement).appendChild(style);
}

function updateDocumentTitle() {
  if (document.title.includes('- Tìm trên Google')) {
    const query = document.title.replace(' - Tìm trên Google', '').trim();
    document.title = `TungCreative - ${query}`;
  } else if (document.title.includes(' - Google Search')) {
    const query = document.title.replace(' - Google Search', '').trim();
    document.title = `TungCreative - ${query}`;
  }
}

async function replaceSearchHeaderLogo() {
  const data = await chrome.storage.local.get(['useEventLogo']);
  const isEvent = !!data.useEventLogo;
  const base64Data = await getLogoBase64(isEvent);

  const logoLink = document.querySelector('a#logo, a[title*="Google"], .logo a, header a[href*="webhp"]');
  if (!logoLink) return;

  logoLink.href = 'javascript:void(0);';
  logoLink.title = 'Về trang chủ TungCreative';
  logoLink.style.overflow = 'visible';

  if (!logoLink.dataset.tstNavBound) {
    logoLink.dataset.tstNavBound = 'true';
    logoLink.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      chrome.runtime.sendMessage({ action: 'OPEN_NEW_TAB' });
    });
  }

  let customImg = logoLink.querySelector('#tungcreative-search-logo');

  if (!customImg) {
    logoLink.innerHTML = '';
    customImg = document.createElement('img');
    customImg.id = 'tungcreative-search-logo';
    customImg.alt = 'Tung Creative';
    logoLink.appendChild(customImg);
  }

  const logoTag = isEvent ? 'event' : 'default';
  if (customImg.dataset.logoFile !== logoTag) {
    customImg.src = base64Data;
    customImg.dataset.logoFile = logoTag;
    customImg.style.cssText = 'height: 32px !important; width: auto !important; max-width: 140px !important; object-fit: contain !important; display: block !important; margin: auto 0 !important; cursor: pointer !important; transition: opacity 0.2s ease, transform 0.2s ease !important; transform-origin: left center !important;';

    customImg.onmouseenter = () => {
      customImg.style.transform = 'scale(1.08)';
      customImg.style.filter = 'brightness(1.1)';
    };
    customImg.onmouseleave = () => {
      customImg.style.transform = 'scale(1)';
      customImg.style.filter = 'none';
    };
  }
}

function initAll() {
  injectThemeStyles();
  updateDocumentTitle();
  replaceSearchHeaderLogo();
}
initAll();

chrome.storage.onChanged.addListener((changes) => {
  if (changes.useEventLogo) {
    currentBase64 = null;
    currentLogoName = null;
    const oldImg = document.getElementById('tungcreative-search-logo');
    if (oldImg) oldImg.removeAttribute('data-logo-file');
    replaceSearchHeaderLogo();
  }
});

const observer = new MutationObserver(() => {
  updateDocumentTitle();
  const customImg = document.getElementById('tungcreative-search-logo');
  if (!customImg || !document.contains(customImg)) {
    replaceSearchHeaderLogo();
  }
});

if (document.documentElement) {
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });
}